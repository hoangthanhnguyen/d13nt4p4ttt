jQuery(document).ready( function($){
	 
	
}) // global end
